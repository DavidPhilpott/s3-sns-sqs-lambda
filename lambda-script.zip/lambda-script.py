def lambda-handler(key, event):
	print("Running")
	print(key)
	print(event)