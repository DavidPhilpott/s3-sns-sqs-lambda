def handler(key, event):
	print("Running")
	print("Key: %s, Event: %s" %(key, event))
	return